class addNewNote extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        this.renderNewNote();
        this.newNoteAdded();
    }

    renderNewNote() {
        const form = document.createElement('form');
        form.innerHTML = `
            <h2>Tambahkan notes baru</h2>
            <label for="title">Judul:</label><br>
            <input type="text" id="title" name="title" required><br><br>
            <label for="body">Isi:</label><br>
            <textarea id="body" name="body" rows="4" cols="50" required></textarea><br><br>
            <button type="submit">Tambahkan Catatan</button>
        `;

        const style = document.createElement('style');
        style.textContent = `
            form {
                max-width: 500px;
                margin:10px auto;
                padding: 40px;
                background-color: #453F78;
                border-radius: 8px;
                box-shadow: 0px 0px 5px 0px rgba(0,0,0,0.85);
            }
            
            label {
                display: block;
                font-size: 16px;
                color: #fff;
            }
            
            input[type="text"],
            textarea {
                width: 100%;
                padding: 10px;
                border: none;
                border-radius: 4px;
                background-color: #fff;
                color: #453F78;
                font-size: 16px;
            }
            
            textarea {
                resize: vertical;
                min-height: 100px;
            }
            
            button[type="submit"] {
                padding: 10px 20px;
                border: none;
                border-radius: 4px;
                background-color: #f9b234;
                color: #fff;
                font-size: 16px;
                cursor: pointer;
                transition: background-color 0.3s ease;
            }
            
            button[type="submit"]:hover {
                background-color: #e69a0f;
            }
            
            @media screen and (max-width: 768px) {
                form {
                    max-width: 90%;
                }
                
                input[type="text"],
                textarea {
                    width: calc(100% - 20px); 
                }
                
                button[type="submit"] {
                    font-size: 14px;
                    padding: 8px 16px; 
                }
            }
            
            @media screen and (max-width: 480px) {
                input[type="text"],
                textarea {
                    font-size: 14px; 
                }
                
                button[type="submit"] {
                    font-size: 12px; 
                    padding: 6px 12px; 
                }
            }            
            
        `;

        this.shadowRoot.appendChild(style);
        this.shadowRoot.appendChild(form);
    }

    newNoteAdded() {
        const form = this.shadowRoot.querySelector('form');
        const titleInput = form.querySelector('#title');
        const bodyInput = form.querySelector('#body');
    
        form.addEventListener('submit', event => {
            event.preventDefault();
            if (form.checkValidity()) {
                const formData = new FormData(form);
                const title = formData.get('title');
                const body = formData.get('body');
                const eventToAddNote = new CustomEvent('newNoteAdded', { detail: { title, body } });
                document.dispatchEvent(eventToAddNote);
                form.reset();
            }
        });
    
        titleInput.addEventListener('input', () => {
            if (!titleInput.validity.valid) {
                titleInput.setCustomValidity('Bagian ini harus diisi');
            } else {
                titleInput.setCustomValidity('');
            }
        });
    
        bodyInput.addEventListener('input', () => {
            if (!bodyInput.validity.valid) {
                bodyInput.setCustomValidity('Bagian ini harus terdiri dari min 1 karakter');
            } else {
                bodyInput.setCustomValidity('');
            }
        });
    }
}    
customElements.define('add-new-note', addNewNote);
