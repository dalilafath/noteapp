import './addNewNote.js';
import './noteList.js';
import './searchNote.js';
